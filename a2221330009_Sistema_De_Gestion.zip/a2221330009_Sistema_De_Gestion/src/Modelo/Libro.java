package Modelo;

public class Libro {

    private String nombreLibro;
    private String autor;
    private int anio;
    private String idSerie;

    public Libro(String nombreLibro, String autor, int anio, String idSerie) {
        this.nombreLibro = nombreLibro;
        this.autor = autor;
        this.anio = anio;
        this.idSerie = idSerie;
    }

    public String getNombreLibro() {
        return nombreLibro;
    }

    public void setNombreLibro(String nombreLibro) {
        this.nombreLibro = nombreLibro;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getIdSerie() {
        return idSerie;
    }

    public void setIdSerie(String idSerie) {
        this.idSerie = idSerie;
    }

    @Override
    public String toString() {
        return nombreLibro + " - " + autor + " - Año: " + anio + " - ID Serie: " + idSerie;
    }
}
