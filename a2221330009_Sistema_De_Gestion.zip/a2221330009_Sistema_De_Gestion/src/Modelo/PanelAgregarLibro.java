package Modelo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelo.Libro;
import Modelo.Libro;

public class PanelAgregarLibro extends JPanel {

    private JTextField txtNombre;
    private JTextField txtPuesto;
    private JTextField txtEdad;
    private JTextField txtIdEmpleado;
    private JButton btnGuardar;

    public PanelAgregarLibro() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new GridLayout(5, 20, 30, 10));

        add(new JLabel("Nombre del libro:"));
        txtNombre = new JTextField();
        add(txtNombre);

        add(new JLabel("Autor:"));
        txtPuesto = new JTextField();
        add(txtPuesto);

        add(new JLabel("Año"));
        txtEdad = new JTextField();
        add(txtEdad);

        add(new JLabel("Numero de serie:"));
        txtIdEmpleado = new JTextField();
        add(txtIdEmpleado);

        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarPersona();
            }
        });
        add(btnGuardar);
    }

    private void guardarPersona() {
        try {
            String nombre = txtNombre.getText();
            String puesto = txtPuesto.getText();
            int edad = Integer.parseInt(txtEdad.getText());
            String idEmpleado = txtIdEmpleado.getText();

            Libro persona = new Libro(nombre, puesto, edad, idEmpleado);

            JOptionPane.showMessageDialog(this, "Libro agregado correctamente:\n" + persona);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Fecha del libro invalida. Por favor ingresa un número.");
        }
    }
}
