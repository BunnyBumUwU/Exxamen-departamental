package Controlador;

import Vista.PanelPrincipal;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class A2221330009_Sistema_De_Gestion {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame ventana = new JFrame("Sistema de Gestión");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setContentPane(new PanelPrincipal());
            ventana.pack();
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
    }
}
