
package Controlador;

import Modelo.Libro;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Type;



public class LibroGuardar {
      private static final String ARCHIVO_JSON = "libros.json";

    public static void guardarLibros(List<Libro> libros) {
        try (Writer writer = new FileWriter(ARCHIVO_JSON)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(libros, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Libro> cargarLibros() {
        File archivo = new File(ARCHIVO_JSON);
        if (!archivo.exists()) {
           return new ArrayList<>();
        }

        try (Reader reader = new FileReader(archivo)) {
            Gson gson = new Gson();
            Type tipoLista = new TypeToken<List<Libro>>(){}.getType();
            return gson.fromJson(reader, tipoLista);
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
    

