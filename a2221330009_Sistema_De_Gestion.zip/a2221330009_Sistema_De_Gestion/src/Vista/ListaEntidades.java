
package Vista;

import Controlador.LibroGuardar;
import Modelo.Libro;
import Modelo.PanelAgregarLibro;
import Vista.PanelPrincipal;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;



public class ListaEntidades extends javax.swing.JPanel {
    public ListaEntidades() {
        initComponents();
          
    
    cargarLibrosEnTabla();


    cargarLibrosEnTabla();


    } 
        
private void cargarLibrosEnTabla() {
    List<Libro> lista = LibroGuardar.cargarLibros();
    DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();
    modelo.setRowCount(0);  

    for (Libro libro : lista) {
        modelo.addRow(new Object[]{
            libro.getNombreLibro(),
            libro.getAutor(),
            libro.getAnio(),
            libro.getIdSerie()
        });
    }
}

// Acción para el botón Actualizar: recarga la tabla
private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {
    cargarLibrosEnTabla();

    }

    private void editarLibroDesdeFila(int fila) {
    DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();

    String nombreLibro = (String) modelo.getValueAt(fila, 0);
    String autor = (String) modelo.getValueAt(fila, 1);
    int anio = (int) modelo.getValueAt(fila, 2);
    String idSerie = (String) modelo.getValueAt(fila, 3);

    // Crear panel con los campos para editar
    JPanel panel = new JPanel(new GridLayout(4, 2));
    JTextField campoNombre = new JTextField(nombreLibro);
    JTextField campoAutor = new JTextField(autor);
    JTextField campoAnio = new JTextField(String.valueOf(anio));
    JTextField campoIdSerie = new JTextField(idSerie);

    panel.add(new JLabel("Nombre del libro:"));
    panel.add(campoNombre);
    panel.add(new JLabel("Autor:"));
    panel.add(campoAutor);
    panel.add(new JLabel("Año:"));
    panel.add(campoAnio);
    panel.add(new JLabel("ID de serie:"));
    panel.add(campoIdSerie);

    int opcion = JOptionPane.showConfirmDialog(this, panel, "Editar Libro", JOptionPane.OK_CANCEL_OPTION);

    if (opcion == JOptionPane.OK_OPTION) {
        try {
            String nuevoNombre = campoNombre.getText().trim();
            String nuevoAutor = campoAutor.getText().trim();
            int nuevoAnio = Integer.parseInt(campoAnio.getText().trim());
            String nuevoIdSerie = campoIdSerie.getText().trim();

            if (nuevoNombre.isEmpty() || nuevoAutor.isEmpty() || nuevoIdSerie.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.");
                return;
            }

            // Cargar lista de libros
            List<Libro> listaLibros = LibroGuardar.cargarLibros();

            // Buscar el libro en la lista para modificarlo (usando nombre original e idSerie original)
            for (Libro libro : listaLibros) {
                if (libro.getNombreLibro().equals(nombreLibro) && libro.getIdSerie().equals(idSerie)) {
                    libro.setNombreLibro(nuevoNombre);
                    libro.setAutor(nuevoAutor);
                    libro.setAnio(nuevoAnio);
                    libro.setIdSerie(nuevoIdSerie);
                    break;
                }
            }

            // Guardar cambios
            LibroGuardar.guardarLibros(listaLibros);

            // Actualizar tabla
            btnActualizarActionPerformed(null);

            JOptionPane.showMessageDialog(this, "Libro modificado correctamente.");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El año debe ser un número válido.");
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaLibros = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        btnActualizar1 = new javax.swing.JButton();

        tablaLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaLibros);

        jPanel1.setBackground(new java.awt.Color(255, 255, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnEliminar.setText("Eliminar libro...");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 100, 270, 50));

        btnRegresar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnRegresar.setText("Regresar al menu principal");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 270, 50));

        btnActualizar1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnActualizar1.setText("Actualizar datos");
        btnActualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 30, 270, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1177, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
 int fila = tablaLibros.getSelectedRow();

    if (fila == -1) {
        JOptionPane.showMessageDialog(this,
            "Debes seleccionar un libro para eliminar.", "Error",
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    int confirmar = JOptionPane.showConfirmDialog(this,
        "¿Estás seguro que quieres eliminar este libro?", "Confirmar eliminación",
        JOptionPane.YES_NO_OPTION);

    if (confirmar == JOptionPane.YES_OPTION) {
        eliminarLibroDesdeFila(fila);
    }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        JFrame ventana = (JFrame) SwingUtilities.getWindowAncestor(this);
    ventana.setContentPane(new PanelPrincipal());
    ventana.revalidate();
    ventana.repaint();

    
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnActualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizar1ActionPerformed
         JFrame ventana = (JFrame) SwingUtilities.getWindowAncestor(this);
    ventana.setContentPane(new PanelAgregarLibro());
    ventana.revalidate();
    ventana.repaint();

    }//GEN-LAST:event_btnActualizar1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar1;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaLibros;
    // End of variables declaration//GEN-END:variables

    private void eliminarLibroDesdeFila(int fila) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
