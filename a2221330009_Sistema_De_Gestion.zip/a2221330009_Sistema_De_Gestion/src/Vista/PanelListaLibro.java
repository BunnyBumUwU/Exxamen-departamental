package Vista;

import Modelo.Libro;
import Controlador.LibroGuardar;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class PanelListaLibro extends JPanel {

    private JTable tablaLibros;
    private DefaultTableModel modelo;
    private JButton btnRegresar;
    private JButton btnActualizar;
    private JButton btnEliminar;  // Agregado botón eliminar

    public PanelListaLibro() {
        setLayout(new BorderLayout());

        modelo = new DefaultTableModel(new String[]{"Nombre", "Autor", "Año", "ID Serie"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Evita edición directa en la tabla
            }
        };
        tablaLibros = new JTable(modelo);

        JScrollPane scrollPane = new JScrollPane(tablaLibros);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");   // Crear botón eliminar
        btnRegresar = new JButton("Regresar");

        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);  // Añadir botón eliminar al panel
        panelBotones.add(btnRegresar);
        add(panelBotones, BorderLayout.SOUTH);

        // Acción del botón Actualizar (editar libro seleccionado)
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int fila = tablaLibros.getSelectedRow();

                if (fila == -1) {
                    JOptionPane.showMessageDialog(PanelListaLibro.this,
                            "Debes seleccionar un libro para actualizar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                editarLibroDesdeFila(fila);
            }
        });

        // Acción del botón Eliminar (eliminar libro seleccionado)
        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int fila = tablaLibros.getSelectedRow();

                if (fila == -1) {
                    JOptionPane.showMessageDialog(PanelListaLibro.this,
                            "Debes seleccionar un libro para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int confirmar = JOptionPane.showConfirmDialog(PanelListaLibro.this,
                        "¿Seguro que quieres eliminar este libro?", "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION);

                if (confirmar == JOptionPane.YES_OPTION) {
                    eliminarLibroDesdeFila(fila);
                }
            }
        });

        // Acción del botón Regresar
        btnRegresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(PanelListaLibro.this);
                topFrame.setContentPane(new PanelPrincipal());
                topFrame.revalidate();
                topFrame.repaint();
            }
        });

        cargarLibrosEnTabla();
    }

    private void cargarLibrosEnTabla() {
        List<Libro> lista = LibroGuardar.cargarLibros();
        modelo.setRowCount(0);  // Limpiar tabla

        for (Libro l : lista) {
            modelo.addRow(new Object[]{
                    l.getNombreLibro(),
                    l.getAutor(),
                    l.getAnio(),
                    l.getIdSerie()
            });
        }
    }

    private void editarLibroDesdeFila(int fila) {
        String nombreLibro = (String) modelo.getValueAt(fila, 0);
        String autor = (String) modelo.getValueAt(fila, 1);
        int anio = (int) modelo.getValueAt(fila, 2);
        String idSerie = (String) modelo.getValueAt(fila, 3);

        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        JTextField campoNombre = new JTextField(nombreLibro);
        JTextField campoAutor = new JTextField(autor);
        JTextField campoAnio = new JTextField(String.valueOf(anio));
        JTextField campoIdSerie = new JTextField(idSerie);

        panel.add(new JLabel("Nombre del libro:"));
        panel.add(campoNombre);
        panel.add(new JLabel("Autor:"));
        panel.add(campoAutor);
        panel.add(new JLabel("Año:"));
        panel.add(campoAnio);
        panel.add(new JLabel("ID de serie:"));
        panel.add(campoIdSerie);

        int opcion = JOptionPane.showConfirmDialog(this, panel, "Editar Libro", JOptionPane.OK_CANCEL_OPTION);

        if (opcion == JOptionPane.OK_OPTION) {
            try {
                String nuevoNombre = campoNombre.getText().trim();
                String nuevoAutor = campoAutor.getText().trim();
                int nuevoAnio = Integer.parseInt(campoAnio.getText().trim());
                String nuevoIdSerie = campoIdSerie.getText().trim();

                if (nuevoNombre.isEmpty() || nuevoAutor.isEmpty() || nuevoIdSerie.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.");
                    return;
                }

                List<Libro> listaLibros = LibroGuardar.cargarLibros();

                boolean actualizado = false;
                for (Libro libro : listaLibros) {
                    if (libro.getNombreLibro().equals(nombreLibro) && libro.getIdSerie().equals(idSerie)) {
                        libro.setNombreLibro(nuevoNombre);
                        libro.setAutor(nuevoAutor);
                        libro.setAnio(nuevoAnio);
                        libro.setIdSerie(nuevoIdSerie);
                        actualizado = true;
                        break;
                    }
                }

                if (actualizado) {
                    LibroGuardar.guardarLibros(listaLibros);
                    cargarLibrosEnTabla();
                    JOptionPane.showMessageDialog(this, "Libro modificado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "No se encontró el libro para modificar.");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El año debe ser un número válido.");
            }
        }
    }

    private void eliminarLibroDesdeFila(int fila) {
        String nombreLibro = (String) modelo.getValueAt(fila, 0);
        String autor = (String) modelo.getValueAt(fila, 1);
        int anio = (int) modelo.getValueAt(fila, 2);
        String idSerie = (String) modelo.getValueAt(fila, 3);

        List<Libro> listaLibros = LibroGuardar.cargarLibros();

        boolean eliminado = listaLibros.removeIf(libro ->
                libro.getNombreLibro().equals(nombreLibro) &&
                        libro.getAutor().equals(autor) &&
                        libro.getAnio() == anio &&
                        libro.getIdSerie().equals(idSerie)
        );

        if (eliminado) {
            LibroGuardar.guardarLibros(listaLibros);
            cargarLibrosEnTabla();
            JOptionPane.showMessageDialog(this, "Libro eliminado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar el libro.");
        }
    }
}
